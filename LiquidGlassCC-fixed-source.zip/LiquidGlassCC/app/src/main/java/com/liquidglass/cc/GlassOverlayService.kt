package com.liquidglass.cc

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.media.AudioManager
import android.provider.Settings.System
import com.example.liquidglass.GlassMaterial
import com.example.liquidglass.LiquidGlassView

class GlassOverlayService : Service() {
    private lateinit var wm: WindowManager
    private var root: FrameLayout? = null
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onCreate() { super.onCreate(); wm = getSystemService(WINDOW_SERVICE) as WindowManager; show() }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int { if (root == null) show(); return START_NOT_STICKY }

    private fun text(s: String, size: Float, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(Color.WHITE)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }
    private fun glassCard(title: String, subtitle: String): LiquidGlassView {
        val glass = LiquidGlassView(this).apply {
            cornerRadius = dp(24).toFloat()
            glassTint = 0x443B659A
            enableDynamicBackground = true
            material = GlassMaterial.REGULAR
            refractionHeight = dp(48).toFloat()
            bevelWidth = dp(14).toFloat()
            dispersionStrength = 0.08f
            enableSensorHighlight = true
            enableAdaptiveTint = true
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(12))
            addView(text(title, 13f, true)); addView(text(subtitle, 17f))
        }
        glass.addView(content, FrameLayout.LayoutParams(-1, -1))
        return glass
    }
    private fun show() {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        val backdrop = FrameLayout(this).apply { setBackgroundColor(0x33050A14) }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(20), dp(18), dp(18))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xE51B2638.toInt(), 0xE6101726.toInt())).apply {
                cornerRadius = dp(32).toFloat(); setStroke(dp(1), 0x66FFFFFF)
            }
        }
        val heading = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        heading.addView(text("Control Center", 24f, true), LinearLayout.LayoutParams(0, -2, 1f))
        heading.addView(text("✕", 22f).apply { setOnClickListener { stopSelf() } })
        panel.addView(heading)
        panel.addView(text("LIQUID GLASS  •  OPPO", 11f, true))
        panel.addView(glassCard("NOW PLAYING", "No active media session").also {
            panel.addView(it, LinearLayout.LayoutParams(-1, dp(90)).apply { topMargin = dp(12) })
        })
        val audio = getSystemService(AUDIO_SERVICE) as AudioManager
        panel.addView(text("Brightness", 13f, true))
        val brightness = SeekBar(this).apply {
            max = 255; progress = try { System.getInt(contentResolver, System.SCREEN_BRIGHTNESS) } catch (_: Exception) { 128 }
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                    if (user && System.canWrite(this@GlassOverlayService)) System.putInt(contentResolver, System.SCREEN_BRIGHTNESS, p)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        panel.addView(brightness)
        panel.addView(text("Volume", 13f, true))
        panel.addView(SeekBar(this).apply {
            max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            progress = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { if (user) audio.setStreamVolume(AudioManager.STREAM_MUSIC, p, 0) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        val shortcuts = listOf("Wi-Fi" to "android.settings.panel.action.WIFI", "Bluetooth" to Settings.ACTION_BLUETOOTH_SETTINGS,
            "Location" to Settings.ACTION_LOCATION_SOURCE_SETTINGS, "Airplane" to Settings.ACTION_AIRPLANE_MODE_SETTINGS)
        shortcuts.chunked(2).forEach { pair ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            pair.forEach { (name, action) ->
                val tile = glassCard(name, "Open settings")
                tile.setOnClickListener { try { startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {} }
                row.addView(tile, LinearLayout.LayoutParams(0, dp(76), 1f).apply { setMargins(dp(3), dp(4), dp(3), dp(4)) })
            }
            panel.addView(row)
        }
        val battery = (getSystemService(BATTERY_SERVICE) as android.os.BatteryManager)
            .getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)
        panel.addView(glassCard("DEVICE", "Battery  •  $battery%"), LinearLayout.LayoutParams(-1, dp(70)).apply { topMargin = dp(8) })
        backdrop.addView(panel, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER).apply { setMargins(dp(12), dp(18), dp(12), dp(18)) })
        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        val flags = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        val params = WindowManager.LayoutParams(-1, -1, type, flags, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP }
        root = backdrop
        wm.addView(backdrop, params)
        backdrop.alpha = 0f; backdrop.animate().alpha(1f).setDuration(220).start()
    }
    override fun onDestroy() { root?.let { try { wm.removeView(it) } catch (_: Exception) {} }; root = null; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
