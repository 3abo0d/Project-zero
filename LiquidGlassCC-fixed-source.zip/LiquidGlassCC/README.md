# LiquidGlassCC
Experimental ColorOS 16 Control Center overlay for Android 16.

Uses QWEA0/Liquid-Glass-Android v2.0.11. The JitPack dependency is `com.github.QWEA0:liquidglass:v2.0.11`.

Build with `gradle --no-daemon assembleDebug` using JDK 17 and Gradle 8.11.1.

This is an early build scaffold. Some controls open Android Settings rather than toggling protected settings. Media session controls and cross-app backdrop capture are not implemented yet. The library samples its own view hierarchy; separate-window cross-app refraction is not guaranteed.
