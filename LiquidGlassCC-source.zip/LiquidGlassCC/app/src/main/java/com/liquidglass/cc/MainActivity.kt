package com.liquidglass.cc

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(36), dp(24), dp(24))
            setBackgroundColor(Color.rgb(14, 18, 29))
        }
        page.addView(TextView(this).apply {
            text = "LiquidGlassCC"
            textSize = 30f
            setTextColor(Color.WHITE)
        })
        page.addView(TextView(this).apply {
            text = "A translucent Control Center overlay for ColorOS 16."
            textSize = 15f
            setTextColor(0xFFB8C2D9.toInt())
            setPadding(0, dp(8), 0, dp(24))
        })
        page.addView(TextView(this).apply {
            text = "1. Allow display over other apps.\\n2. Allow modify system settings for brightness.\n3. Start the overlay."
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, dp(24))
        })
        page.addView(actionButton("Grant overlay permission") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        page.addView(actionButton("Grant brightness permission") {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
        })
        page.addView(actionButton("Start Liquid Glass Control Center") {
            if (Settings.canDrawOverlays(this)) {
                startService(Intent(this, GlassOverlayService::class.java))
            } else {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        })
        page.addView(actionButton("Stop overlay") {
            stopService(Intent(this, GlassOverlayService::class.java))
        })
        page.addView(TextView(this).apply {
            text = "Build 0.1.0 • Experimental first milestone"
            textSize = 12f
            setTextColor(0xFF8290AA.toInt())
            setPadding(0, dp(28), 0, 0)
        })
        setContentView(page)
    }

    private fun actionButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        gravity = Gravity.CENTER
        setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(-1, dp(54))
        lp.bottomMargin = dp(12)
        layoutParams = lp
    }
}
