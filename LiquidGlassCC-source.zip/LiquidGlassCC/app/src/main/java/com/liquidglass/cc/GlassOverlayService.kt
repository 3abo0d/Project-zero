package com.liquidglass.cc

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.content.Context
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import android.content.ComponentName
import android.content.ActivityNotFoundException
import android.provider.Settings.Panel
import android.hardware.camera2.CameraManager
import android.content.res.ColorStateList
import android.graphics.Typeface
import com.example.liquidglass.LiquidGlassView
import com.example.liquidglass.GlassMaterial

class GlassOverlayService : Service() {
    private lateinit var wm: WindowManager
    private var overlay: View? = null
    private var torchOn = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showOverlay()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (overlay == null) showOverlay()
        return START_NOT_STICKY
    }

    private fun showOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        val root = FrameLayout(this).apply {
            setBackgroundColor(0x22060A14)
            isClickable = true
        }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(18))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xD91C2638.toInt(), 0xCC111827.toInt(), 0xE6111828.toInt())
            ).apply { cornerRadius = dp(34).toFloat(); setStroke(dp(1), 0x66FFFFFF) }
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        top.addView(label("Control Center", 23f, true), LinearLayout.LayoutParams(0, -2, 1f))
        val close = TextView(this).apply {
            text = "✕"
            textSize = 22f
            setTextColor(Color.WHITE)
            setPadding(dp(12), dp(4), dp(4), dp(4))
            setOnClickListener { removeOverlay() }
        }
        top.addView(close)
        panel.addView(top)

        panel.addView(label("SUNDAY  •  LIQUID GLASS", 10f, true).apply {
            setTextColor(0xFFB8C8E8.toInt())
            setPadding(0, dp(8), 0, dp(12))
        })

        val media = glassCard("♫   NOW PLAYING", "No active media session", "Previous       Play       Next")
        panel.addView(media, verticalParams(112))

        val sliders = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        sliders.addView(sliderRow("Brightness", 0, 255, Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128)) { value ->
            if (Settings.System.canWrite(this@GlassOverlayService)) {
                Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, value)
            } else {
                toast("Allow Modify system settings in the app first")
            }
        })
        val audio = getSystemService(AUDIO_SERVICE) as AudioManager
        sliders.addView(sliderRow("Volume", 0, audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC), audio.getStreamVolume(AudioManager.STREAM_MUSIC)) { value ->
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, value, 0)
        })
        panel.addView(sliders, verticalParams(116))

        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(tile("Wi-Fi", "◉") { openPanel("android.settings.panel.action.WIFI") }, weightParams())
        row1.addView(tile("Bluetooth", "ᛒ") { openIntent(Settings.ACTION_BLUETOOTH_SETTINGS) }, weightParams())
        row1.addView(tile("Location", "⌖") { openIntent(Settings.ACTION_LOCATION_SOURCE_SETTINGS) }, weightParams())
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row2.addView(tile("Airplane", "✈") { openIntent(Settings.ACTION_AIRPLANE_MODE_SETTINGS) }, weightParams())
        row2.addView(tile("Rotate", "⟳") { openIntent(Settings.ACTION_DISPLAY_SETTINGS) }, weightParams())
        row2.addView(tile("Flashlight", "☼") { toggleTorch() }, weightParams())
        grid.addView(row1)
        grid.addView(row2)
        panel.addView(grid, verticalParams(148))

        panel.addView(glassCard("DEVICE", "Battery  •  ${batteryPercent()}%     OPPO A6 Pro 5G", "Connected devices and battery status"), verticalParams(82))
        panel.addView(label("Swipe down to dismiss  •  Tap outside to close", 11f, false).apply {
            gravity = Gravity.CENTER
            setTextColor(0xFF9EABC2.toInt())
            setPadding(0, dp(12), 0, 0)
        })

        root.addView(panel, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER).apply {
            leftMargin = dp(12); rightMargin = dp(12); topMargin = dp(18); bottomMargin = dp(18)
        })
        root.setOnClickListener { removeOverlay() }
        panel.setOnClickListener { /* consume panel taps */ }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_DIM_BEHIND or\n                (if (Build.VERSION.SDK_INT >= 31) WindowManager.LayoutParams.FLAG_BLUR_BEHIND else 0),
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            dimAmount = 0.28f
            if (Build.VERSION.SDK_INT >= 31) {
                setBlurBehindRadius(dp(24))
            }
        }
        overlay = root
        wm.addView(root, params)
        root.alpha = 0f
        root.animate().alpha(1f).setDuration(220).start()
    }

    private fun glassCard(kicker: String, title: String, subtitle: String): View {
        val glass = LiquidGlassView(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, dp(96))
            cornerRadius = dp(26).toFloat()
            glassTint = 0x332F5F9F
            enableDynamicBackground = true
            if (Build.VERSION.SDK_INT >= 33) {
                material = GlassMaterial.REGULAR
                refractionHeight = dp(54).toFloat()
                bevelWidth = dp(18).toFloat()
                dispersionStrength = 0.08f
                enableSensorHighlight = true
                enableAdaptiveTint = true
            } else {
                blurAmount = 0.09f
                saturation = 135f
                enableEdgeHighlight = true
            }
            setBackgroundColor(0x332D4568)
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(10))
            isClickable = false
        }
        content.addView(label(kicker, 10f, true).apply { setTextColor(0xFFB8C8E8.toInt()) })
        content.addView(label(title, 16f, true).apply { setPadding(0, dp(4), 0, dp(2)) })
        content.addView(label(subtitle, 11f, false).apply { setTextColor(0xFFD3DCEF.toInt()) })
        glass.addView(content, FrameLayout.LayoutParams(-1, -1))
        return glass
    }

    private fun sliderRow(name: String, min: Int, max: Int, initial: Int, changed: (Int) -> Unit): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(4), dp(4), dp(2))
        }
        box.addView(label(name, 12f, true))
        val seek = SeekBar(this).apply {
            this.max = max - min
            progress = (initial - min).coerceIn(0, max - min)
            progressTintList = ColorStateList.valueOf(0xFFE5F0FF.toInt())
            thumbTintList = ColorStateList.valueOf(Color.WHITE)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { if (user) changed(p + min) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        box.addView(seek)
        return box
    }

    private fun tile(name: String, symbol: String, action: () -> Unit): View {
        val glass = LiquidGlassView(this).apply {
            cornerRadius = dp(22).toFloat()
            glassTint = 0x443A5C91
            enableDynamicBackground = true
            if (Build.VERSION.SDK_INT >= 33) {
                material = GlassMaterial.REGULAR
                refractionHeight = dp(36).toFloat()
                bevelWidth = dp(12).toFloat()
                dispersionStrength = 0.06f
            } else {
                blurAmount = 0.07f
            }
            setBackgroundColor(0x443A4D6C)
            setOnClickListener { action() }
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            isClickable = false
            addView(label(symbol, 22f, true).apply { gravity = Gravity.CENTER })
            addView(label(name, 11f, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(4), 0, 0) })
        }
        glass.addView(content, FrameLayout.LayoutParams(-1, -1))
        return glass
    }

    private fun label(value: String, size: Float, bold: Boolean) = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(Color.WHITE)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun verticalParams(height: Int) = LinearLayout.LayoutParams(-1, dp(height)).apply {
        topMargin = dp(8)
    }
    private fun weightParams() = LinearLayout.LayoutParams(0, dp(68), 1f).apply {
        marginEnd = dp(6); bottomMargin = dp(6)
    }

    private fun openPanel(action: String) {
        try {
            startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) { toast("This system panel is unavailable; opening Settings"); openIntent(Settings.ACTION_WIFI_SETTINGS) }
    }

    private fun openIntent(action: String) {
        try { startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (_: Exception) { toast("This setting is unavailable on this device") }
    }

    private fun toggleTorch() {
        try {
            val manager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = manager.cameraIdList.firstOrNull { manager.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            if (cameraId == null) { toast("Flashlight unavailable"); return }
            torchOn = !torchOn
            manager.setTorchMode(cameraId, torchOn)
        } catch (_: SecurityException) {
            toast("Flashlight permission is unavailable; use Quick Settings")
        } catch (_: Exception) { toast("Could not toggle flashlight") }
    }

    private fun batteryPercent(): Int {
        val bm = getSystemService(BATTERY_SERVICE) as android.os.BatteryManager
        return bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY).coerceIn(0, 100)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun removeOverlay() {
        overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        overlay = null
        stopSelf()
    }

    override fun onDestroy() {
        overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        overlay = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
