Never commit personal access tokens, signing keys, passwords, or other secrets.
If a token is exposed, revoke it immediately and create a replacement only through a secure credential flow.
