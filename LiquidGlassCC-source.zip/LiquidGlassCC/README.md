# LiquidGlassCC

An experimental Android 16 Control Center overlay for OPPO ColorOS 16.

## Build
GitHub Actions builds `app/build/outputs/apk/debug/app-debug.apk` on pushes to `main` or manual workflow dispatch.

## Install
Install the `LiquidGlassCC-debug` artifact from the Actions run. On first launch:
1. Grant Display over other apps.
2. Grant Modify system settings for brightness.
3. Start the overlay.

## Current milestone
- Kotlin Android app and overlay service.
- QWEA0 Liquid-Glass-Android library integration.
- Brightness and media-volume sliders.
- Wi-Fi system panel and Settings shortcuts for Bluetooth, Location, Airplane mode and rotation.
- Flashlight attempt through CameraManager.
- Battery percentage display.
- Dismiss by tapping outside or the close icon.

## Known limitations
- This is an initial functional scaffold, not a finished replica of the supplied reference.
- The glass library samples its own view hierarchy. The system blur-behind flag may blur the window backdrop on supported devices, but true cross-app refraction is not guaranteed.
- Android/ColorOS may block or alter blur-behind and overlay behavior.
- Some quick settings intentionally open Android Settings rather than silently changing protected system state.
- Flashlight may require additional permission handling on some devices.
- Media controls are currently a visual placeholder; media-session integration is a later milestone.

## Library
QWEA0/Liquid-Glass-Android, MIT license:
https://github.com/QWEA0/Liquid-Glass-Android

The dependency is declared in `app/build.gradle.kts`.
